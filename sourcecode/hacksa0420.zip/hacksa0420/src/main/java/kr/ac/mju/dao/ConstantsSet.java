package kr.ac.mju.dao;

public class ConstantsSet {
	public final static String CONTEXT_PATH = "/oos0420";
	public final static String RESOURCE_PATH = "/src/main/resources";
	

}
