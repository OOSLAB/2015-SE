package kr.ac.mju.dao;

public class DAO {
	protected final static String USER_DATA_FILE = "resources/data/userdata.txt";
	protected final static String GANGJWA_DATA_FILE = "resources/data/gangjwadata.txt";
	protected final static String SUGANG_DATA_FILE = "resources/data/sugangdata.txt";
	protected final static String SPLIT_SEPERATOR = ",";
}
