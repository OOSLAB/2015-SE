package kr.ac.mju.dto;

public class Gangjwa {
	private String id;
	private String name;
	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
